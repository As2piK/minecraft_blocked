# Activate Bordercraft globally (run once per world)
execute if data storage bordercraft:state {active:1b} run return 0
data modify storage bordercraft:state active set value 1b

# Scoreboard: border expansions progress
scoreboard objectives add bc_border dummy
scoreboard objectives modify bc_border displayname "Bordercraft"
scoreboard players set Increases bc_border 0
scoreboard players set Max bc_border 2079
scoreboard objectives add bc_side dummy
scoreboard objectives add bc_ui trigger

# Leaderboard / contributor tracking
scoreboard objectives add bc_contrib_items dummy
scoreboard objectives add bc_contrib_adv dummy
scoreboard objectives add bc_contrib_mobs dummy
scoreboard objectives add bc_contrib_struct dummy
scoreboard objectives add bc_contrib_total dummy
scoreboard objectives add bc_lb_tmp dummy

# UI state (per-player)
scoreboard objectives add bc_ui_filter dummy
scoreboard objectives add bc_ui_last dummy

# Boss kill tracking (unlimited expansions for dragon/wither/warden)
scoreboard objectives add bc_k_dragon minecraft.killed:minecraft.ender_dragon
scoreboard objectives add bc_k_wither minecraft.killed:minecraft.wither
scoreboard objectives add bc_k_warden minecraft.killed:minecraft.warden
scoreboard objectives add bc_kd_prev dummy
scoreboard objectives add bc_kw_prev dummy
scoreboard objectives add bc_kwd_prev dummy
scoreboard objectives add bc_tmp dummy
scoreboard players set TWO bc_tmp 2
scoreboard players set TEN bc_tmp 10

# Respawn safety: detect player deaths and move them back into the border on respawn
scoreboard objectives add bc_deaths deathCount
scoreboard objectives add bc_deaths_last dummy
scoreboard objectives add bc_time_since_death minecraft.custom:minecraft.time_since_death
scoreboard objectives add bc_respawn_pending dummy
# Failsafe: mined dirt/sand tracking for consecutive early-game expansions
scoreboard objectives add bc_mined_dirt minecraft.mined:minecraft.dirt
scoreboard objectives add bc_mined_sand minecraft.mined:minecraft.sand
scoreboard objectives add bc_mined_grass_block minecraft.mined:minecraft.grass_block
scoreboard objectives add bc_mined_podzol minecraft.mined:minecraft.podzol
scoreboard objectives add bc_mined_mycelium minecraft.mined:minecraft.mycelium
scoreboard objectives add bc_mined_farmland minecraft.mined:minecraft.farmland
scoreboard objectives add bc_mined_dirt_path minecraft.mined:minecraft.dirt_path
scoreboard objectives add bc_md_prev dummy
scoreboard objectives add bc_ms_prev dummy
scoreboard objectives add bc_mg_prev dummy
scoreboard objectives add bc_mp_prev dummy
scoreboard objectives add bc_mm_prev dummy
scoreboard objectives add bc_mf_prev dummy
scoreboard objectives add bc_mdp_prev dummy
scoreboard objectives add bc_fs_tmp dummy
scoreboard objectives add bc_fs_evt dummy

# Multi-dimension border syncing (nether runs at 1/8 rate; end matches overworld)
scoreboard objectives add bc_nether_accum dummy
scoreboard players set NetherAcc bc_nether_accum 0
data modify storage bordercraft:state dim_init set value 1b


# Early-game dirt/sand failsafe streak tracking
scoreboard objectives add bc_fs_state dummy
scoreboard objectives add bc_fs_count dummy

# Initialize early-game dirt/sand failsafe globals
scoreboard players set FS bc_fs_state 0
scoreboard players set FS bc_fs_count 0
scoreboard objectives modify bc_side displayname [{"text":"B","color":"red"},{"text":"o","color":"gold"},{"text":"r","color":"yellow"},{"text":"d","color":"green"},{"text":"e","color":"aqua"},{"text":"r","color":"blue"},{"text":"c","color":"dark_purple"},{"text":"r","color":"light_purple"},{"text":"a","color":"red"},{"text":"f","color":"gold"},{"text":"t","color":"yellow"}]
scoreboard players set Items/1672 bc_side 0
scoreboard players set Adv/125 bc_side 0
scoreboard players set Mobs/62 bc_side 0
scoreboard players set Struct/22 bc_side 0
scoreboard players set Bosses bc_side 0

# Colorize scoreboard lines via teams (avoids changing any scoreboard player names used elsewhere)
team remove bc_items
team remove bc_adv
team remove bc_mobs
team remove bc_struct
team remove bc_bosses

team add bc_items
team add bc_adv
team add bc_mobs
team add bc_struct
team add bc_bosses

team modify bc_items color blue
team modify bc_adv color light_purple
team modify bc_mobs color red
team modify bc_struct color green
team modify bc_bosses color dark_purple

team join bc_items Items/1672
team join bc_adv Adv/125
team join bc_mobs Mobs/62
team join bc_struct Struct/22
team join bc_bosses Bosses
scoreboard objectives setdisplay sidebar bc_side



## Start location selection / setup (avoid oceans at 0,0)
# Note: Do not summon anchors at 0,0 directly; that chunk may not be loaded when activating.
# find_start will run setup_start at the chosen location (which also creates the anchor and sets border/spawn).
function bordercraft:find_start
# Fallback: if no start was found in the search grid, start at 0,0 anyway
execute unless data storage bordercraft:state {start_found:1b} positioned 0.5 0 0.5 run function bordercraft:select_start

# Initialize per-player death trackers so we don't treat past deaths as new events
execute as @a run scoreboard players operation @s bc_deaths_last = @s bc_deaths
tellraw @a ["",{"text":"Bordercraft activated!","color":"green"},{"text":"  ("},{"score":{"name":"Increases","objective":"bc_border"}},{"text":" / "},{"score":{"name":"Max","objective":"bc_border"}},{"text":")","color":"gray"}]
playsound entity.player.levelup master @a ~ ~ ~ 1000 1
