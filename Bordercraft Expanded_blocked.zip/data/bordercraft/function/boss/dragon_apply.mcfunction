execute if score @s bc_tmp matches 1.. run function bordercraft:boss/dragon_apply_once
