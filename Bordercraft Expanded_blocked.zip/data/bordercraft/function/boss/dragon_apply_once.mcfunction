scoreboard players remove @s bc_tmp 1
scoreboard players add Bosses bc_side 1

# Repeat-kill behavior: purple message, does NOT increase unique "Increases"
execute if data storage bordercraft:once {mob:{kill__ender_dragon:1b}} run function bordercraft:boss/expand_dragon

# First-time kill behavior: counts as unique mob + normal expansion message
execute unless data storage bordercraft:once {mob:{kill__ender_dragon:1b}} run function bordercraft:once/mob/kill__ender_dragon

execute if score @s bc_tmp matches 1.. run function bordercraft:boss/dragon_apply_once
