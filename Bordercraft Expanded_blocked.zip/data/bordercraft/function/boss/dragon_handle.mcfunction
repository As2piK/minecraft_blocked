scoreboard players operation @s bc_tmp = @s bc_k_dragon
scoreboard players operation @s bc_tmp -= @s bc_kd_prev
function bordercraft:boss/dragon_apply
