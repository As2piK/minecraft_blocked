execute unless data storage bordercraft:state {active:1b} run return 0
execute if score @s bc_k_dragon > @s bc_kd_prev run function bordercraft:boss/dragon_handle
scoreboard players operation @s bc_kd_prev = @s bc_k_dragon
