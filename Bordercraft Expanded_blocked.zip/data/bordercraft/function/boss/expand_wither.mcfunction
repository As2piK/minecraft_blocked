worldborder add 2
tellraw @a ["",{"text":"The Wither has expanded the world!","color":"light_purple"}]
playsound entity.experience_orb.pickup master @a ~ ~ ~ 1000 2
