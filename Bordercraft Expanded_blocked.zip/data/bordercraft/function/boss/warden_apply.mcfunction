execute if score @s bc_tmp matches 1.. run function bordercraft:boss/warden_apply_once
