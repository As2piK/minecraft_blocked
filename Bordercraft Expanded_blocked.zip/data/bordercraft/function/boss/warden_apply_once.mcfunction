scoreboard players remove @s bc_tmp 1
scoreboard players add Bosses bc_side 1

execute if data storage bordercraft:once {mob:{kill__warden:1b}} run function bordercraft:boss/expand_warden
execute unless data storage bordercraft:once {mob:{kill__warden:1b}} run function bordercraft:once/mob/kill__warden

execute if score @s bc_tmp matches 1.. run function bordercraft:boss/warden_apply_once
