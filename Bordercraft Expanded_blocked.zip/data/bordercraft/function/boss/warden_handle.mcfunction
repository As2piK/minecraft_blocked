scoreboard players operation @s bc_tmp = @s bc_k_warden
scoreboard players operation @s bc_tmp -= @s bc_kwd_prev
function bordercraft:boss/warden_apply
