execute unless data storage bordercraft:state {active:1b} run return 0
execute if score @s bc_k_warden > @s bc_kwd_prev run function bordercraft:boss/warden_handle
scoreboard players operation @s bc_kwd_prev = @s bc_k_warden
