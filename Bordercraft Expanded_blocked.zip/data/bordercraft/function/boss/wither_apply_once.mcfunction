scoreboard players remove @s bc_tmp 1
scoreboard players add Bosses bc_side 1

execute if data storage bordercraft:once {mob:{kill__wither:1b}} run function bordercraft:boss/expand_wither
execute unless data storage bordercraft:once {mob:{kill__wither:1b}} run function bordercraft:once/mob/kill__wither

execute if score @s bc_tmp matches 1.. run function bordercraft:boss/wither_apply_once
