scoreboard players operation @s bc_tmp = @s bc_k_wither
scoreboard players operation @s bc_tmp -= @s bc_kw_prev
function bordercraft:boss/wither_apply
