execute unless data storage bordercraft:state {active:1b} run return 0
execute if score @s bc_k_wither > @s bc_kw_prev run function bordercraft:boss/wither_handle
scoreboard players operation @s bc_kw_prev = @s bc_k_wither
