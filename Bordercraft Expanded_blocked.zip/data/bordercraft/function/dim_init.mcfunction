# One-time setup/upgrade for multi-dimension border syncing (safe to run on existing worlds)

# Track how many overworld expansions have occurred since the last nether border increase.
# Every 8 overworld expansions => +1 nether expansion (i.e., +2 to diameter) to match 1:8 scale.
scoreboard objectives add bc_nether_accum dummy
scoreboard players set NetherAcc bc_nether_accum 0

data modify storage bordercraft:state dim_init set value 1b
