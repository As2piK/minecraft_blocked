# Enables Bordercraft "all mob kills" mode (adds optional passive/utility mobs as eligible unique mob kills)
# Run: /function bordercraft:enableallmobkills

execute unless data storage bordercraft:state {active:1b} run tellraw @s [{"text":"Bordercraft is not active in this world yet.","color":"red"},{"text":"  Run ","color":"gray"},{"text":"/function bordercraft:activate","color":"yellow"},{"text":" first.","color":"gray"}]
execute unless data storage bordercraft:state {active:1b} run return 0

execute if data storage bordercraft:state {enable_all_mobkills:1b} run tellraw @s [{"text":"All-mob-kills mode is already enabled.","color":"yellow"}]
execute if data storage bordercraft:state {enable_all_mobkills:1b} run return 0

# Flag
data modify storage bordercraft:state enable_all_mobkills set value 1b

# Increase overall max (+25 optional mobs) and update the mobs line max (58 -> 83)
scoreboard players add Max bc_border 26

# Create / migrate the sidebar mob progress line
scoreboard players set Mobs/88 bc_side 0
scoreboard players operation Mobs/88 bc_side = Mobs/62 bc_side
team join bc_mobs Mobs/88
team leave Mobs/62
scoreboard players reset Mobs/62 bc_side

# Revoke the optional-mob advancements so they can be earned after enabling (in case they were granted earlier)
advancement revoke @a only minecraft:border/kill__camel
advancement revoke @a only minecraft:border/kill__donkey
advancement revoke @a only minecraft:border/kill__horse
advancement revoke @a only minecraft:border/kill__cat
advancement revoke @a only minecraft:border/kill__mule
advancement revoke @a only minecraft:border/kill__parrot
advancement revoke @a only minecraft:border/kill__wolf
advancement revoke @a only minecraft:border/kill__armadillo
advancement revoke @a only minecraft:border/kill__bat
advancement revoke @a only minecraft:border/kill__bee
advancement revoke @a only minecraft:border/kill__goat
advancement revoke @a only minecraft:border/kill__fox
advancement revoke @a only minecraft:border/kill__llama
advancement revoke @a only minecraft:border/kill__ocelot
advancement revoke @a only minecraft:border/kill__panda
advancement revoke @a only minecraft:border/kill__polar_bear
advancement revoke @a only minecraft:border/kill__axolotl
advancement revoke @a only minecraft:border/kill__dolphin
advancement revoke @a only minecraft:border/kill__frog
advancement revoke @a only minecraft:border/kill__tadpole
advancement revoke @a only minecraft:border/kill__turtle
advancement revoke @a only minecraft:border/kill__allay
advancement revoke @a only minecraft:border/kill__sniffer
advancement revoke @a only minecraft:border/kill__copper_golem
advancement revoke @a only minecraft:border/kill__trader_llama
advancement revoke @a only minecraft:border/kill__happy_ghast

tellraw @a [{"text":"Bordercraft: ","color":"gold"},{"text":"Optional mob kills enabled!","color":"green"},{"text":"  (+26 max) ","color":"gray"},{"text":"/function bordercraft:enableallmobkills","color":"yellow"}]
playsound entity.player.levelup master @a ~ ~ ~ 1000 1
