# Give players fall-damage protection when returning from the End to the Overworld.
# World spawn is set high in the air, so exiting the End can cause a long fall.
# The main loop clears Resistance automatically when the player is grounded.

effect give @s resistance infinite 255 true
tag @s remove bc_was_in_end
