# Expand the world border by 2 blocks

# Early-game dirt/sand failsafe gating (global)
# FS state: 0=eligible (no first unique yet), 1=dirt streak, 2=sand streak, 3=ended/ineligible
# A temporary storage flag bordercraft:ctx.fs_keep is set ONLY when the current unique expansion is dirt or sand,
# so we can enforce: first unique must be dirt/sand, and the first five uniques must be strictly dirt OR sand.
execute if score FS bc_fs_state matches 0 unless data storage bordercraft:ctx {fs_keep:1b} run scoreboard players set FS bc_fs_state 3
execute if score FS bc_fs_state matches 1..2 if score FS bc_fs_count matches ..4 unless data storage bordercraft:ctx {fs_keep:1b} run scoreboard players set FS bc_fs_state 3
execute if score FS bc_fs_count matches 5.. run scoreboard players set FS bc_fs_state 3

# Overworld + End expand at the same rate
execute in minecraft:overworld run worldborder add .1
execute in minecraft:the_end run worldborder add .1

# Nether expands at the same rate (1:1 with overworld)
execute in minecraft:the_nether run worldborder add .1


# Update progress scoreboard (global)
scoreboard players add Increases bc_border 1

execute if data storage bordercraft:ctx {cause_set:1b} run tellraw @a ["",{"text":"The world has expanded from ","color":"yellow"},{"nbt":"cause","storage":"bordercraft:ctx","interpret":true,"color":"yellow"},{"text":"  ("},{"score":{"name":"Increases","objective":"bc_border"}},{"text":" / "},{"score":{"name":"Max","objective":"bc_border"}},{"text":")","color":"gray"}]
execute unless data storage bordercraft:ctx {cause_set:1b} run tellraw @a ["",{"text":"The world has expanded!","color":"yellow"},{"text":"  ("},{"score":{"name":"Increases","objective":"bc_border"}},{"text":" / "},{"score":{"name":"Max","objective":"bc_border"}},{"text":")","color":"gray"}]
data remove storage bordercraft:ctx cause_set
data remove storage bordercraft:ctx cause
playsound entity.experience_orb.pickup master @a ~ ~ ~ 1000 2
