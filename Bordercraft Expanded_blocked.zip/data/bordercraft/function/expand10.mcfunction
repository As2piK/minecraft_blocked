# Expand the world border by 20 blocks (10 expansions)
# Overworld + End expand at the same rate
execute in minecraft:overworld run worldborder add 1
execute in minecraft:the_end run worldborder add 1

# Nether expands at the same rate (1:1 with overworld)
execute in minecraft:the_nether run worldborder add 1


# Update progress scoreboard (global)
scoreboard players add Increases bc_border 10

execute if data storage bordercraft:ctx {cause_set:1b} run tellraw @a ["",{"text":"A new ","color":"green"},{"nbt":"cause","storage":"bordercraft:ctx","interpret":true,"color":"green"},{"text":" was discovered! ","color":"green"},{"text":"(+10 expansions)","color":"gray"},{"text":"  ("},{"score":{"name":"Increases","objective":"bc_border"}},{"text":" / "},{"score":{"name":"Max","objective":"bc_border"}},{"text":")","color":"gray"}]
execute unless data storage bordercraft:ctx {cause_set:1b} run tellraw @a ["",{"text":"A new structure was discovered!","color":"green"},{"text":"  ("},{"score":{"name":"Increases","objective":"bc_border"}},{"text":" / "},{"score":{"name":"Max","objective":"bc_border"}},{"text":")","color":"gray"}]
data remove storage bordercraft:ctx cause_set
data remove storage bordercraft:ctx cause
playsound entity.experience_orb.pickup master @a ~ ~ ~ 1000 2
