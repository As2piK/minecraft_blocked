# Expand the world border by 2 blocks (no unique counter increase)
# Overworld + End expand at the same rate
execute in minecraft:overworld run worldborder add .1
execute in minecraft:the_end run worldborder add .1

# Nether expands at the same rate (1:1 with overworld)
execute in minecraft:the_nether run worldborder add .1


tellraw @a ["",{"text":"The world has expanded (NON UNIQUE)!","color":"yellow"}]
playsound entity.experience_orb.pickup master @a ~ ~ ~ 0.8 1
