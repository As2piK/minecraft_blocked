# Apply one extra dirt-streak expansion (no unique counters).
# Must still be eligible
execute unless score FS bc_fs_state matches 1 run return 0
execute unless score FS bc_fs_count matches ..4 run return 0

scoreboard players add FS bc_fs_count 1
function bordercraft:expand_nounique
execute if score FS bc_fs_count matches 5.. run scoreboard players set FS bc_fs_state 3
