# Handle each mined dirt block (repeat up to bc_fs_tmp times), applying extra expansions only when allowed.

# If we're currently in a sand streak, switching ends the streak immediately.
execute if score FS bc_fs_state matches 2 run scoreboard players set FS bc_fs_state 3

# Only apply expansions if we're in a dirt streak and under limit (count 1..4 before increment).
execute if score FS bc_fs_state matches 1 if score FS bc_fs_count matches ..4 run function bordercraft:failsafe/dirt_apply_once

# Consume one delta and recurse if more remain
scoreboard players remove @s bc_fs_tmp 1
execute if score @s bc_fs_tmp matches 1.. run function bordercraft:failsafe/process_dirt
