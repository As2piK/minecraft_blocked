# Extra early-game expansions for consecutive sand (up to 5)
# Only runs on repeat sand pickups (i.e., sand already obtained once).

# Must be in sand streak
execute unless score FS bc_fs_state matches 2 run return 0
# Must be under limit (count 1..4)
execute unless score FS bc_fs_count matches ..4 run return 0

scoreboard players add FS bc_fs_count 1
function bordercraft:expand_nounique
