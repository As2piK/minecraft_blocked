execute unless data storage bordercraft:state {active:1b} run return 0

# Detect mined dirt/sand and apply early-game consecutive expansion streak (global rules in FS bc_fs_state/bc_fs_count).
# Uses per-player minecraft.mined stats, but updates the global FS counters so it works in multiplayer too.

# --- DIRT EVENT (any block treated as dirt) ---
# Dirt includes: dirt, grass_block, podzol, mycelium, farmland, dirt_path

# bc_fs_tmp = total dirt-type mined delta this tick (can be >1 due to lag/spam)
scoreboard players set @s bc_fs_tmp 0

# dirt
scoreboard players operation @s bc_fs_evt = @s bc_mined_dirt
scoreboard players operation @s bc_fs_evt -= @s bc_md_prev
execute if score @s bc_fs_evt matches 1.. run scoreboard players operation @s bc_fs_tmp += @s bc_fs_evt

# grass_block
scoreboard players operation @s bc_fs_evt = @s bc_mined_grass_block
scoreboard players operation @s bc_fs_evt -= @s bc_mg_prev
execute if score @s bc_fs_evt matches 1.. run scoreboard players operation @s bc_fs_tmp += @s bc_fs_evt

# podzol
scoreboard players operation @s bc_fs_evt = @s bc_mined_podzol
scoreboard players operation @s bc_fs_evt -= @s bc_mp_prev
execute if score @s bc_fs_evt matches 1.. run scoreboard players operation @s bc_fs_tmp += @s bc_fs_evt

# mycelium
scoreboard players operation @s bc_fs_evt = @s bc_mined_mycelium
scoreboard players operation @s bc_fs_evt -= @s bc_mm_prev
execute if score @s bc_fs_evt matches 1.. run scoreboard players operation @s bc_fs_tmp += @s bc_fs_evt

# farmland (breaks to dirt)
scoreboard players operation @s bc_fs_evt = @s bc_mined_farmland
scoreboard players operation @s bc_fs_evt -= @s bc_mf_prev
execute if score @s bc_fs_evt matches 1.. run scoreboard players operation @s bc_fs_tmp += @s bc_fs_evt

# dirt_path (breaks to dirt)
scoreboard players operation @s bc_fs_evt = @s bc_mined_dirt_path
scoreboard players operation @s bc_fs_evt -= @s bc_mdp_prev
execute if score @s bc_fs_evt matches 1.. run scoreboard players operation @s bc_fs_tmp += @s bc_fs_evt

execute if score @s bc_fs_tmp matches 1.. run function bordercraft:failsafe/process_dirt


# --- SAND EVENT ---
# bc_fs_tmp = sand mined delta this tick
scoreboard players operation @s bc_fs_evt = @s bc_mined_sand
scoreboard players operation @s bc_fs_evt -= @s bc_ms_prev
scoreboard players operation @s bc_fs_tmp = @s bc_fs_evt
execute if score @s bc_fs_tmp matches 1.. run function bordercraft:failsafe/process_sand


# Update prev to current
scoreboard players operation @s bc_md_prev = @s bc_mined_dirt
scoreboard players operation @s bc_mg_prev = @s bc_mined_grass_block
scoreboard players operation @s bc_mp_prev = @s bc_mined_podzol
scoreboard players operation @s bc_mm_prev = @s bc_mined_mycelium
scoreboard players operation @s bc_mf_prev = @s bc_mined_farmland
scoreboard players operation @s bc_mdp_prev = @s bc_mined_dirt_path
scoreboard players operation @s bc_ms_prev = @s bc_mined_sand
