# Keep Max bc_border synchronized with the current intended total.
# Base total: 2079
# With enableallmobkills: 2105

execute unless data storage bordercraft:state {enable_all_mobkills:1b} run scoreboard players set Max bc_border 2079
execute if data storage bordercraft:state {enable_all_mobkills:1b} run scoreboard players set Max bc_border 2105
