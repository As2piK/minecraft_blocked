# One-time correction for existing worlds:
# Current correct base total is 2079.
# If optional mob kills are enabled, total is 2105.

execute unless data storage bordercraft:state {enable_all_mobkills:1b} run scoreboard players set Max bc_border 2079
execute if data storage bordercraft:state {enable_all_mobkills:1b} run scoreboard players set Max bc_border 2105
data modify storage bordercraft:state fix_max_v1 set value 1b
