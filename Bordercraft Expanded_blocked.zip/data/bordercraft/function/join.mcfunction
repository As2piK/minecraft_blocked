# Teleport a newly joined player into the active Bordercraft start border
# (Run as the player)
execute at @e[tag=bc_anchor,limit=1] run tp @s ~ 257 ~
# Ensure the player's respawn point is always inside the border
execute at @e[tag=bc_anchor,limit=1] run spawnpoint @s ~ 257 ~
# Give Resistance 255 until they land (loop removes it on ground)
effect give @s resistance infinite 255 true
# Mark as initialized so we don't repeat
tag @s add bc_joined

# Initialize death tracker so we don't treat prior deaths as new
scoreboard players operation @s bc_deaths_last = @s bc_deaths
