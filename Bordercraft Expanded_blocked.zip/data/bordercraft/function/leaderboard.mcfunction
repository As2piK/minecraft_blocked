# /function bordercraft:leaderboard
# Shows the top contributors (unique achievements credited) in this world.

tag @a remove bc_lb_ranked
tag @a remove bc_lb_best
tag @a remove bc_lb_r1
tag @a remove bc_lb_r2
tag @a remove bc_lb_r3
tag @a remove bc_lb_r4
tag @a remove bc_lb_r5

tellraw @s {"text":"","extra":[{"text":"— Bordercraft Leaderboard —","color":"gold","bold":true}]}
tellraw @s {"text":"","extra":[{"text":"(Total uniques credited: Items + Advancements + Mobs + Structures)","color":"gray"}]}
tellraw @s {"text":"","extra":[{"text":""}]}

# Rank 1
scoreboard players set Best bc_lb_tmp -1
execute as @a[tag=!bc_lb_ranked] if score @s bc_contrib_total > Best bc_lb_tmp run function bordercraft:leaderboard/_select_best
execute as @a[tag=bc_lb_best] run tag @s add bc_lb_r1
execute as @a[tag=bc_lb_r1] run tag @s add bc_lb_ranked
tag @a remove bc_lb_best

# Rank 2
scoreboard players set Best bc_lb_tmp -1
execute as @a[tag=!bc_lb_ranked] if score @s bc_contrib_total > Best bc_lb_tmp run function bordercraft:leaderboard/_select_best
execute as @a[tag=bc_lb_best] run tag @s add bc_lb_r2
execute as @a[tag=bc_lb_r2] run tag @s add bc_lb_ranked
tag @a remove bc_lb_best

# Rank 3
scoreboard players set Best bc_lb_tmp -1
execute as @a[tag=!bc_lb_ranked] if score @s bc_contrib_total > Best bc_lb_tmp run function bordercraft:leaderboard/_select_best
execute as @a[tag=bc_lb_best] run tag @s add bc_lb_r3
execute as @a[tag=bc_lb_r3] run tag @s add bc_lb_ranked
tag @a remove bc_lb_best

# Rank 4
scoreboard players set Best bc_lb_tmp -1
execute as @a[tag=!bc_lb_ranked] if score @s bc_contrib_total > Best bc_lb_tmp run function bordercraft:leaderboard/_select_best
execute as @a[tag=bc_lb_best] run tag @s add bc_lb_r4
execute as @a[tag=bc_lb_r4] run tag @s add bc_lb_ranked
tag @a remove bc_lb_best

# Rank 5
scoreboard players set Best bc_lb_tmp -1
execute as @a[tag=!bc_lb_ranked] if score @s bc_contrib_total > Best bc_lb_tmp run function bordercraft:leaderboard/_select_best
execute as @a[tag=bc_lb_best] run tag @s add bc_lb_r5
execute as @a[tag=bc_lb_r5] run tag @s add bc_lb_ranked
tag @a remove bc_lb_best

execute if entity @a[tag=bc_lb_r1] run tellraw @s {"text":"","extra":[{"text":"1) ","color":"yellow"},{"selector":"@a[tag=bc_lb_r1,limit=1]"},{"text":" — Total: ","color":"gray"},{"score":{"name":"@a[tag=bc_lb_r1,limit=1]","objective":"bc_contrib_total"}},{"text":"  (","color":"dark_gray"},{"text":"I:","color":"blue"},{"score":{"name":"@a[tag=bc_lb_r1,limit=1]","objective":"bc_contrib_items"}},{"text":", ","color":"dark_gray"},{"text":"A:","color":"light_purple"},{"score":{"name":"@a[tag=bc_lb_r1,limit=1]","objective":"bc_contrib_adv"}},{"text":", ","color":"dark_gray"},{"text":"M:","color":"red"},{"score":{"name":"@a[tag=bc_lb_r1,limit=1]","objective":"bc_contrib_mobs"}},{"text":", ","color":"dark_gray"},{"text":"S:","color":"green"},{"score":{"name":"@a[tag=bc_lb_r1,limit=1]","objective":"bc_contrib_struct"}},{"text":")","color":"dark_gray"}]}
execute if entity @a[tag=bc_lb_r2] run tellraw @s {"text":"","extra":[{"text":"2) ","color":"yellow"},{"selector":"@a[tag=bc_lb_r2,limit=1]"},{"text":" — Total: ","color":"gray"},{"score":{"name":"@a[tag=bc_lb_r2,limit=1]","objective":"bc_contrib_total"}},{"text":"  (","color":"dark_gray"},{"text":"I:","color":"blue"},{"score":{"name":"@a[tag=bc_lb_r2,limit=1]","objective":"bc_contrib_items"}},{"text":", ","color":"dark_gray"},{"text":"A:","color":"light_purple"},{"score":{"name":"@a[tag=bc_lb_r2,limit=1]","objective":"bc_contrib_adv"}},{"text":", ","color":"dark_gray"},{"text":"M:","color":"red"},{"score":{"name":"@a[tag=bc_lb_r2,limit=1]","objective":"bc_contrib_mobs"}},{"text":", ","color":"dark_gray"},{"text":"S:","color":"green"},{"score":{"name":"@a[tag=bc_lb_r2,limit=1]","objective":"bc_contrib_struct"}},{"text":")","color":"dark_gray"}]}
execute if entity @a[tag=bc_lb_r3] run tellraw @s {"text":"","extra":[{"text":"3) ","color":"yellow"},{"selector":"@a[tag=bc_lb_r3,limit=1]"},{"text":" — Total: ","color":"gray"},{"score":{"name":"@a[tag=bc_lb_r3,limit=1]","objective":"bc_contrib_total"}},{"text":"  (","color":"dark_gray"},{"text":"I:","color":"blue"},{"score":{"name":"@a[tag=bc_lb_r3,limit=1]","objective":"bc_contrib_items"}},{"text":", ","color":"dark_gray"},{"text":"A:","color":"light_purple"},{"score":{"name":"@a[tag=bc_lb_r3,limit=1]","objective":"bc_contrib_adv"}},{"text":", ","color":"dark_gray"},{"text":"M:","color":"red"},{"score":{"name":"@a[tag=bc_lb_r3,limit=1]","objective":"bc_contrib_mobs"}},{"text":", ","color":"dark_gray"},{"text":"S:","color":"green"},{"score":{"name":"@a[tag=bc_lb_r3,limit=1]","objective":"bc_contrib_struct"}},{"text":")","color":"dark_gray"}]}
execute if entity @a[tag=bc_lb_r4] run tellraw @s {"text":"","extra":[{"text":"4) ","color":"yellow"},{"selector":"@a[tag=bc_lb_r4,limit=1]"},{"text":" — Total: ","color":"gray"},{"score":{"name":"@a[tag=bc_lb_r4,limit=1]","objective":"bc_contrib_total"}},{"text":"  (","color":"dark_gray"},{"text":"I:","color":"blue"},{"score":{"name":"@a[tag=bc_lb_r4,limit=1]","objective":"bc_contrib_items"}},{"text":", ","color":"dark_gray"},{"text":"A:","color":"light_purple"},{"score":{"name":"@a[tag=bc_lb_r4,limit=1]","objective":"bc_contrib_adv"}},{"text":", ","color":"dark_gray"},{"text":"M:","color":"red"},{"score":{"name":"@a[tag=bc_lb_r4,limit=1]","objective":"bc_contrib_mobs"}},{"text":", ","color":"dark_gray"},{"text":"S:","color":"green"},{"score":{"name":"@a[tag=bc_lb_r4,limit=1]","objective":"bc_contrib_struct"}},{"text":")","color":"dark_gray"}]}
execute if entity @a[tag=bc_lb_r5] run tellraw @s {"text":"","extra":[{"text":"5) ","color":"yellow"},{"selector":"@a[tag=bc_lb_r5,limit=1]"},{"text":" — Total: ","color":"gray"},{"score":{"name":"@a[tag=bc_lb_r5,limit=1]","objective":"bc_contrib_total"}},{"text":"  (","color":"dark_gray"},{"text":"I:","color":"blue"},{"score":{"name":"@a[tag=bc_lb_r5,limit=1]","objective":"bc_contrib_items"}},{"text":", ","color":"dark_gray"},{"text":"A:","color":"light_purple"},{"score":{"name":"@a[tag=bc_lb_r5,limit=1]","objective":"bc_contrib_adv"}},{"text":", ","color":"dark_gray"},{"text":"M:","color":"red"},{"score":{"name":"@a[tag=bc_lb_r5,limit=1]","objective":"bc_contrib_mobs"}},{"text":", ","color":"dark_gray"},{"text":"S:","color":"green"},{"score":{"name":"@a[tag=bc_lb_r5,limit=1]","objective":"bc_contrib_struct"}},{"text":")","color":"dark_gray"}]}