# Internal helper: tag the current executor as best and store their score in Best

tag @a remove bc_lb_best
tag @s add bc_lb_best
scoreboard players operation Best bc_lb_tmp = @s bc_contrib_total
