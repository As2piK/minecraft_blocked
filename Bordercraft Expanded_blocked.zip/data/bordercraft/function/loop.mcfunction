advancement revoke @a only minecraft:border/__loop
execute unless data storage bordercraft:state {active:1b} run return 0
execute unless data storage bordercraft:state {migrate_luck_v1:1b} run function bordercraft:migrate_luck_v1
execute unless data storage bordercraft:state {migrate_items_1677:1b} run function bordercraft:migrate_items_1677
execute unless data storage bordercraft:state {migrate_items_1669:1b} run function bordercraft:migrate_items_1669
execute unless data storage bordercraft:state {migrate_items_1671:1b} run function bordercraft:migrate_items_1671
execute unless data storage bordercraft:state {migrate_items_1678:1b} run function bordercraft:migrate_items_1678
execute unless data storage bordercraft:state {migrate_items_1674:1b} run function bordercraft:migrate_items_1674
execute unless data storage bordercraft:state {migrate_items_1675:1b} run function bordercraft:migrate_items_1675
execute unless data storage bordercraft:state {migrate_items_1672:1b} run function bordercraft:migrate_items_1672
function bordercraft:fix_max_current
execute unless data storage bordercraft:state {respawn_init:1b} run function bordercraft:respawn_init
execute unless data storage bordercraft:state {ui_init:1b} run function bordercraft:ui_init
execute unless data storage bordercraft:state {dim_init:1b} run function bordercraft:dim_init
forceload add 0 0
execute as @a run execute at @s run execute unless block ~ ~-0.001 ~ air run effect clear @s resistance

# If a player returns to the overworld after being in the End (e.g., jumping through the exit portal),
# they can spawn at the (air) world spawn and fall. Give the same Resistance 255 safety effect
# used on first activation/respawn, cleared by the grounded check above.
execute as @a at @s if dimension minecraft:the_end run tag @s add bc_was_in_end
execute as @a[tag=bc_was_in_end] at @s if dimension minecraft:overworld run function bordercraft:end_return

# Any players who join after activation are moved into the chosen start border
execute as @a[tag=!bc_joined] run function bordercraft:join

# UI triggers (prevents click confirmation popups)
scoreboard players enable @a bc_ui
scoreboard players add @a bc_ui_filter 0
scoreboard players add @a bc_ui_page 0
scoreboard players add @a bc_ui_last 0
execute as @a unless score @s bc_ui_page matches 1.. run scoreboard players set @s bc_ui_page 1
execute as @a[scores={bc_ui=1..}] run function bordercraft:ui/dispatch


# Respawn safety: if a player dies and respawns outside the border, move them back inside.
execute as @a run function bordercraft:respawn_tick

# Early-game dirt/sand consecutive-break failsafe (runs regardless of unique detection)
execute as @a run function bordercraft:failsafe/tick


# Unlimited boss kills (dragon / wither / warden): always expand 1x, but only first kill counts as unique
execute as @a run function bordercraft:boss/dragon_tick
execute as @a run function bordercraft:boss/wither_tick
execute as @a run function bordercraft:boss/warden_tick


# Expand border 10x for each unique structure discovered (once per world)
execute as @a at @s run function bordercraft:once/structure/ancient_city
execute as @a at @s run function bordercraft:once/structure/bastion_remnant
execute as @a at @s run function bordercraft:once/structure/desert_pyramid
execute as @a at @s run function bordercraft:once/structure/end_city
execute as @a at @s run function bordercraft:once/structure/fortress
execute as @a at @s run function bordercraft:once/structure/igloo
execute as @a at @s run function bordercraft:once/structure/jungle_pyramid
execute as @a at @s run function bordercraft:once/structure/mansion
execute as @a at @s run function bordercraft:once/structure/mineshaft
execute as @a at @s run function bordercraft:once/structure/monument
execute as @a at @s run function bordercraft:once/structure/pillager_outpost
execute as @a at @s run function bordercraft:once/structure/ruined_portal
execute as @a at @s run function bordercraft:once/structure/shipwreck
execute as @a at @s run function bordercraft:once/structure/stronghold
execute as @a at @s run function bordercraft:once/structure/swamp_hut
execute as @a at @s run function bordercraft:once/structure/trail_ruins
execute as @a at @s run function bordercraft:once/structure/trial_chambers
execute as @a at @s run function bordercraft:once/structure/village_desert
execute as @a at @s run function bordercraft:once/structure/village_plains
execute as @a at @s run function bordercraft:once/structure/village_savanna
execute as @a at @s run function bordercraft:once/structure/village_snowy
execute as @a at @s run function bordercraft:once/structure/village_taiga


# Failsafe detection for harnesses + copper armor (inventory scan)
execute unless data storage bordercraft:once {item:{white_harness:1b}} as @a[nbt={Inventory:[{id:"minecraft:white_harness"}]}] run function bordercraft:once/item/white_harness
execute unless data storage bordercraft:once {item:{orange_harness:1b}} as @a[nbt={Inventory:[{id:"minecraft:orange_harness"}]}] run function bordercraft:once/item/orange_harness
execute unless data storage bordercraft:once {item:{magenta_harness:1b}} as @a[nbt={Inventory:[{id:"minecraft:magenta_harness"}]}] run function bordercraft:once/item/magenta_harness
execute unless data storage bordercraft:once {item:{light_blue_harness:1b}} as @a[nbt={Inventory:[{id:"minecraft:light_blue_harness"}]}] run function bordercraft:once/item/light_blue_harness
execute unless data storage bordercraft:once {item:{yellow_harness:1b}} as @a[nbt={Inventory:[{id:"minecraft:yellow_harness"}]}] run function bordercraft:once/item/yellow_harness
execute unless data storage bordercraft:once {item:{lime_harness:1b}} as @a[nbt={Inventory:[{id:"minecraft:lime_harness"}]}] run function bordercraft:once/item/lime_harness
execute unless data storage bordercraft:once {item:{pink_harness:1b}} as @a[nbt={Inventory:[{id:"minecraft:pink_harness"}]}] run function bordercraft:once/item/pink_harness
execute unless data storage bordercraft:once {item:{gray_harness:1b}} as @a[nbt={Inventory:[{id:"minecraft:gray_harness"}]}] run function bordercraft:once/item/gray_harness
execute unless data storage bordercraft:once {item:{light_gray_harness:1b}} as @a[nbt={Inventory:[{id:"minecraft:light_gray_harness"}]}] run function bordercraft:once/item/light_gray_harness
execute unless data storage bordercraft:once {item:{cyan_harness:1b}} as @a[nbt={Inventory:[{id:"minecraft:cyan_harness"}]}] run function bordercraft:once/item/cyan_harness
execute unless data storage bordercraft:once {item:{purple_harness:1b}} as @a[nbt={Inventory:[{id:"minecraft:purple_harness"}]}] run function bordercraft:once/item/purple_harness
execute unless data storage bordercraft:once {item:{blue_harness:1b}} as @a[nbt={Inventory:[{id:"minecraft:blue_harness"}]}] run function bordercraft:once/item/blue_harness
execute unless data storage bordercraft:once {item:{brown_harness:1b}} as @a[nbt={Inventory:[{id:"minecraft:brown_harness"}]}] run function bordercraft:once/item/brown_harness
execute unless data storage bordercraft:once {item:{green_harness:1b}} as @a[nbt={Inventory:[{id:"minecraft:green_harness"}]}] run function bordercraft:once/item/green_harness
execute unless data storage bordercraft:once {item:{red_harness:1b}} as @a[nbt={Inventory:[{id:"minecraft:red_harness"}]}] run function bordercraft:once/item/red_harness
execute unless data storage bordercraft:once {item:{black_harness:1b}} as @a[nbt={Inventory:[{id:"minecraft:black_harness"}]}] run function bordercraft:once/item/black_harness
execute unless data storage bordercraft:once {item:{copper_helmet:1b}} as @a[nbt={Inventory:[{id:"minecraft:copper_helmet"}]}] run function bordercraft:once/item/copper_helmet
execute unless data storage bordercraft:once {item:{copper_chestplate:1b}} as @a[nbt={Inventory:[{id:"minecraft:copper_chestplate"}]}] run function bordercraft:once/item/copper_chestplate
execute unless data storage bordercraft:once {item:{copper_leggings:1b}} as @a[nbt={Inventory:[{id:"minecraft:copper_leggings"}]}] run function bordercraft:once/item/copper_leggings
execute unless data storage bordercraft:once {item:{copper_boots:1b}} as @a[nbt={Inventory:[{id:"minecraft:copper_boots"}]}] run function bordercraft:once/item/copper_boots

# Expand border for each unique vanilla advancement completed (auto-generated)
execute as @a[advancements={minecraft:adventure/avoid_vibration=true,minecraft:border/adv__adventure__avoid_vibration=false}] run advancement grant @s only minecraft:border/adv__adventure__avoid_vibration
execute as @a[advancements={minecraft:adventure/brush_armadillo=true,minecraft:border/adv__adventure__brush_armadillo=false}] run advancement grant @s only minecraft:border/adv__adventure__brush_armadillo
execute as @a[advancements={minecraft:adventure/crafters_crafting_crafters=true,minecraft:border/adv__adventure__crafters_crafting_crafters=false}] run advancement grant @s only minecraft:border/adv__adventure__crafters_crafting_crafters
execute as @a[advancements={minecraft:adventure/craft_decorated_pot_using_only_sherds=true,minecraft:border/adv__adventure__craft_decorated_pot_using_only_sherds=false}] run advancement grant @s only minecraft:border/adv__adventure__craft_decorated_pot_using_only_sherds
execute as @a[advancements={minecraft:adventure/fall_from_world_height=true,minecraft:border/adv__adventure__fall_from_world_height=false}] run advancement grant @s only minecraft:border/adv__adventure__fall_from_world_height
execute as @a[advancements={minecraft:adventure/heart_transplanter=true,minecraft:border/adv__adventure__heart_transplanter=false}] run advancement grant @s only minecraft:border/adv__adventure__heart_transplanter
execute as @a[advancements={minecraft:adventure/honey_block_slide=true,minecraft:border/adv__adventure__honey_block_slide=false}] run advancement grant @s only minecraft:border/adv__adventure__honey_block_slide
execute as @a[advancements={minecraft:adventure/kill_a_mob=true,minecraft:border/adv__adventure__kill_a_mob=false}] run advancement grant @s only minecraft:border/adv__adventure__kill_a_mob
execute as @a[advancements={minecraft:adventure/lighten_up=true,minecraft:border/adv__adventure__lighten_up=false}] run advancement grant @s only minecraft:border/adv__adventure__lighten_up
execute as @a[advancements={minecraft:adventure/lightning_rod_with_villager_no_fire=true,minecraft:border/adv__adventure__lightning_rod_with_villager_no_fire=false}] run advancement grant @s only minecraft:border/adv__adventure__lightning_rod_with_villager_no_fire
execute as @a[advancements={minecraft:adventure/minecraft_trials_edition=true,minecraft:border/adv__adventure__minecraft_trials_edition=false}] run advancement grant @s only minecraft:border/adv__adventure__minecraft_trials_edition
execute as @a[advancements={minecraft:adventure/ol_betsy=true,minecraft:border/adv__adventure__ol_betsy=false}] run advancement grant @s only minecraft:border/adv__adventure__ol_betsy
execute as @a[advancements={minecraft:adventure/play_jukebox_in_meadows=true,minecraft:border/adv__adventure__play_jukebox_in_meadows=false}] run advancement grant @s only minecraft:border/adv__adventure__play_jukebox_in_meadows
execute as @a[advancements={minecraft:adventure/read_power_of_chiseled_bookshelf=true,minecraft:border/adv__adventure__read_power_of_chiseled_bookshelf=false}] run advancement grant @s only minecraft:border/adv__adventure__read_power_of_chiseled_bookshelf
execute as @a[advancements={minecraft:adventure/root=true,minecraft:border/adv__adventure__root=false}] run advancement grant @s only minecraft:border/adv__adventure__root
execute as @a[advancements={minecraft:adventure/salvage_sherd=true,minecraft:border/adv__adventure__salvage_sherd=false}] run advancement grant @s only minecraft:border/adv__adventure__salvage_sherd
execute as @a[advancements={minecraft:adventure/shoot_arrow=true,minecraft:border/adv__adventure__shoot_arrow=false}] run advancement grant @s only minecraft:border/adv__adventure__shoot_arrow
execute as @a[advancements={minecraft:adventure/sleep_in_bed=true,minecraft:border/adv__adventure__sleep_in_bed=false}] run advancement grant @s only minecraft:border/adv__adventure__sleep_in_bed
execute as @a[advancements={minecraft:adventure/spyglass_at_dragon=true,minecraft:border/adv__adventure__spyglass_at_dragon=false}] run advancement grant @s only minecraft:border/adv__adventure__spyglass_at_dragon
execute as @a[advancements={minecraft:adventure/spyglass_at_ghast=true,minecraft:border/adv__adventure__spyglass_at_ghast=false}] run advancement grant @s only minecraft:border/adv__adventure__spyglass_at_ghast
execute as @a[advancements={minecraft:adventure/spyglass_at_parrot=true,minecraft:border/adv__adventure__spyglass_at_parrot=false}] run advancement grant @s only minecraft:border/adv__adventure__spyglass_at_parrot
execute as @a[advancements={minecraft:adventure/throw_trident=true,minecraft:border/adv__adventure__throw_trident=false}] run advancement grant @s only minecraft:border/adv__adventure__throw_trident
execute as @a[advancements={minecraft:adventure/trade=true,minecraft:border/adv__adventure__trade=false}] run advancement grant @s only minecraft:border/adv__adventure__trade
execute as @a[advancements={minecraft:adventure/trade_at_world_height=true,minecraft:border/adv__adventure__trade_at_world_height=false}] run advancement grant @s only minecraft:border/adv__adventure__trade_at_world_height
execute as @a[advancements={minecraft:adventure/trim_with_any_armor_pattern=true,minecraft:border/adv__adventure__trim_with_any_armor_pattern=false}] run advancement grant @s only minecraft:border/adv__adventure__trim_with_any_armor_pattern
execute as @a[advancements={minecraft:adventure/under_lock_and_key=true,minecraft:border/adv__adventure__under_lock_and_key=false}] run advancement grant @s only minecraft:border/adv__adventure__under_lock_and_key
execute as @a[advancements={minecraft:adventure/use_lodestone=true,minecraft:border/adv__adventure__use_lodestone=false}] run advancement grant @s only minecraft:border/adv__adventure__use_lodestone
execute as @a[advancements={minecraft:adventure/very_very_frightening=true,minecraft:border/adv__adventure__very_very_frightening=false}] run advancement grant @s only minecraft:border/adv__adventure__very_very_frightening
execute as @a[advancements={minecraft:adventure/voluntary_exile=true,minecraft:border/adv__adventure__voluntary_exile=false}] run advancement grant @s only minecraft:border/adv__adventure__voluntary_exile
execute as @a[advancements={minecraft:adventure/walk_on_powder_snow_with_leather_boots=true,minecraft:border/adv__adventure__walk_on_powder_snow_with_leather_boots=false}] run advancement grant @s only minecraft:border/adv__adventure__walk_on_powder_snow_with_leather_boots
execute as @a[advancements={minecraft:adventure/whos_the_pillager_now=true,minecraft:border/adv__adventure__whos_the_pillager_now=false}] run advancement grant @s only minecraft:border/adv__adventure__whos_the_pillager_now
execute as @a[advancements={minecraft:adventure/who_needs_rockets=true,minecraft:border/adv__adventure__who_needs_rockets=false}] run advancement grant @s only minecraft:border/adv__adventure__who_needs_rockets
execute as @a[advancements={minecraft:end/enter_end_gateway=true,minecraft:border/adv__end__enter_end_gateway=false}] run advancement grant @s only minecraft:border/adv__end__enter_end_gateway
execute as @a[advancements={minecraft:end/find_end_city=true,minecraft:border/adv__end__find_end_city=false}] run advancement grant @s only minecraft:border/adv__end__find_end_city
execute as @a[advancements={minecraft:end/kill_dragon=true,minecraft:border/adv__end__kill_dragon=false}] run advancement grant @s only minecraft:border/adv__end__kill_dragon
execute as @a[advancements={minecraft:end/root=true,minecraft:border/adv__end__root=false}] run advancement grant @s only minecraft:border/adv__end__root
execute as @a[advancements={minecraft:husbandry/allay_deliver_cake_to_note_block=true,minecraft:border/adv__husbandry__allay_deliver_cake_to_note_block=false}] run advancement grant @s only minecraft:border/adv__husbandry__allay_deliver_cake_to_note_block
execute as @a[advancements={minecraft:husbandry/allay_deliver_item_to_player=true,minecraft:border/adv__husbandry__allay_deliver_item_to_player=false}] run advancement grant @s only minecraft:border/adv__husbandry__allay_deliver_item_to_player
execute as @a[advancements={minecraft:husbandry/axolotl_in_a_bucket=true,minecraft:border/adv__husbandry__axolotl_in_a_bucket=false}] run advancement grant @s only minecraft:border/adv__husbandry__axolotl_in_a_bucket
execute as @a[advancements={minecraft:husbandry/breed_an_animal=true,minecraft:border/adv__husbandry__breed_an_animal=false}] run advancement grant @s only minecraft:border/adv__husbandry__breed_an_animal
execute as @a[advancements={minecraft:husbandry/feed_snifflet=true,minecraft:border/adv__husbandry__feed_snifflet=false}] run advancement grant @s only minecraft:border/adv__husbandry__feed_snifflet
execute as @a[advancements={minecraft:husbandry/fishy_business=true,minecraft:border/adv__husbandry__fishy_business=false}] run advancement grant @s only minecraft:border/adv__husbandry__fishy_business
execute as @a[advancements={minecraft:husbandry/kill_axolotl_target=true,minecraft:border/adv__husbandry__kill_axolotl_target=false}] run advancement grant @s only minecraft:border/adv__husbandry__kill_axolotl_target
execute as @a[advancements={minecraft:husbandry/leash_all_frog_variants=true,minecraft:border/adv__husbandry__leash_all_frog_variants=false}] run advancement grant @s only minecraft:border/adv__husbandry__leash_all_frog_variants
execute as @a[advancements={minecraft:husbandry/make_a_sign_glow=true,minecraft:border/adv__husbandry__make_a_sign_glow=false}] run advancement grant @s only minecraft:border/adv__husbandry__make_a_sign_glow
execute as @a[advancements={minecraft:husbandry/obtain_sniffer_egg=true,minecraft:border/adv__husbandry__obtain_sniffer_egg=false}] run advancement grant @s only minecraft:border/adv__husbandry__obtain_sniffer_egg
execute as @a[advancements={minecraft:husbandry/place_dried_ghast_in_water=true,minecraft:border/adv__husbandry__place_dried_ghast_in_water=false}] run advancement grant @s only minecraft:border/adv__husbandry__place_dried_ghast_in_water
execute as @a[advancements={minecraft:husbandry/plant_any_sniffer_seed=true,minecraft:border/adv__husbandry__plant_any_sniffer_seed=false}] run advancement grant @s only minecraft:border/adv__husbandry__plant_any_sniffer_seed
execute as @a[advancements={minecraft:husbandry/plant_seed=true,minecraft:border/adv__husbandry__plant_seed=false}] run advancement grant @s only minecraft:border/adv__husbandry__plant_seed
execute as @a[advancements={minecraft:husbandry/remove_wolf_armor=true,minecraft:border/adv__husbandry__remove_wolf_armor=false}] run advancement grant @s only minecraft:border/adv__husbandry__remove_wolf_armor
execute as @a[advancements={minecraft:husbandry/repair_wolf_armor=true,minecraft:border/adv__husbandry__repair_wolf_armor=false}] run advancement grant @s only minecraft:border/adv__husbandry__repair_wolf_armor
execute as @a[advancements={minecraft:husbandry/ride_a_boat_with_a_goat=true,minecraft:border/adv__husbandry__ride_a_boat_with_a_goat=false}] run advancement grant @s only minecraft:border/adv__husbandry__ride_a_boat_with_a_goat
execute as @a[advancements={minecraft:husbandry/root=true,minecraft:border/adv__husbandry__root=false}] run advancement grant @s only minecraft:border/adv__husbandry__root
execute as @a[advancements={minecraft:husbandry/safely_harvest_honey=true,minecraft:border/adv__husbandry__safely_harvest_honey=false}] run advancement grant @s only minecraft:border/adv__husbandry__safely_harvest_honey
execute as @a[advancements={minecraft:husbandry/silk_touch_nest=true,minecraft:border/adv__husbandry__silk_touch_nest=false}] run advancement grant @s only minecraft:border/adv__husbandry__silk_touch_nest
execute as @a[advancements={minecraft:husbandry/tactical_fishing=true,minecraft:border/adv__husbandry__tactical_fishing=false}] run advancement grant @s only minecraft:border/adv__husbandry__tactical_fishing
execute as @a[advancements={minecraft:husbandry/tadpole_in_a_bucket=true,minecraft:border/adv__husbandry__tadpole_in_a_bucket=false}] run advancement grant @s only minecraft:border/adv__husbandry__tadpole_in_a_bucket
execute as @a[advancements={minecraft:husbandry/tame_an_animal=true,minecraft:border/adv__husbandry__tame_an_animal=false}] run advancement grant @s only minecraft:border/adv__husbandry__tame_an_animal
execute as @a[advancements={minecraft:husbandry/wax_off=true,minecraft:border/adv__husbandry__wax_off=false}] run advancement grant @s only minecraft:border/adv__husbandry__wax_off
execute as @a[advancements={minecraft:husbandry/wax_on=true,minecraft:border/adv__husbandry__wax_on=false}] run advancement grant @s only minecraft:border/adv__husbandry__wax_on
execute as @a[advancements={minecraft:nether/brew_potion=true,minecraft:border/adv__nether__brew_potion=false}] run advancement grant @s only minecraft:border/adv__nether__brew_potion
execute as @a[advancements={minecraft:nether/charge_respawn_anchor=true,minecraft:border/adv__nether__charge_respawn_anchor=false}] run advancement grant @s only minecraft:border/adv__nether__charge_respawn_anchor
execute as @a[advancements={minecraft:nether/create_beacon=true,minecraft:border/adv__nether__create_beacon=false}] run advancement grant @s only minecraft:border/adv__nether__create_beacon
execute as @a[advancements={minecraft:nether/distract_piglin=true,minecraft:border/adv__nether__distract_piglin=false}] run advancement grant @s only minecraft:border/adv__nether__distract_piglin
execute as @a[advancements={minecraft:nether/find_bastion=true,minecraft:border/adv__nether__find_bastion=false}] run advancement grant @s only minecraft:border/adv__nether__find_bastion
execute as @a[advancements={minecraft:nether/find_fortress=true,minecraft:border/adv__nether__find_fortress=false}] run advancement grant @s only minecraft:border/adv__nether__find_fortress
execute as @a[advancements={minecraft:nether/get_wither_skull=true,minecraft:border/adv__nether__get_wither_skull=false}] run advancement grant @s only minecraft:border/adv__nether__get_wither_skull
execute as @a[advancements={minecraft:nether/loot_bastion=true,minecraft:border/adv__nether__loot_bastion=false}] run advancement grant @s only minecraft:border/adv__nether__loot_bastion
execute as @a[advancements={minecraft:nether/obtain_ancient_debris=true,minecraft:border/adv__nether__obtain_ancient_debris=false}] run advancement grant @s only minecraft:border/adv__nether__obtain_ancient_debris
execute as @a[advancements={minecraft:nether/obtain_blaze_rod=true,minecraft:border/adv__nether__obtain_blaze_rod=false}] run advancement grant @s only minecraft:border/adv__nether__obtain_blaze_rod
execute as @a[advancements={minecraft:nether/obtain_crying_obsidian=true,minecraft:border/adv__nether__obtain_crying_obsidian=false}] run advancement grant @s only minecraft:border/adv__nether__obtain_crying_obsidian
execute as @a[advancements={minecraft:nether/ride_strider=true,minecraft:border/adv__nether__ride_strider=false}] run advancement grant @s only minecraft:border/adv__nether__ride_strider
execute as @a[advancements={minecraft:nether/ride_strider_in_overworld_lava=true,minecraft:border/adv__nether__ride_strider_in_overworld_lava=false}] run advancement grant @s only minecraft:border/adv__nether__ride_strider_in_overworld_lava
execute as @a[advancements={minecraft:nether/root=true,minecraft:border/adv__nether__root=false}] run advancement grant @s only minecraft:border/adv__nether__root
execute as @a[advancements={minecraft:nether/summon_wither=true,minecraft:border/adv__nether__summon_wither=false}] run advancement grant @s only minecraft:border/adv__nether__summon_wither
execute as @a[advancements={minecraft:story/deflect_arrow=true,minecraft:border/adv__story__deflect_arrow=false}] run advancement grant @s only minecraft:border/adv__story__deflect_arrow
execute as @a[advancements={minecraft:story/enchant_item=true,minecraft:border/adv__story__enchant_item=false}] run advancement grant @s only minecraft:border/adv__story__enchant_item
execute as @a[advancements={minecraft:story/enter_the_end=true,minecraft:border/adv__story__enter_the_end=false}] run advancement grant @s only minecraft:border/adv__story__enter_the_end
execute as @a[advancements={minecraft:story/enter_the_nether=true,minecraft:border/adv__story__enter_the_nether=false}] run advancement grant @s only minecraft:border/adv__story__enter_the_nether
execute as @a[advancements={minecraft:story/follow_ender_eye=true,minecraft:border/adv__story__follow_ender_eye=false}] run advancement grant @s only minecraft:border/adv__story__follow_ender_eye
execute as @a[advancements={minecraft:story/form_obsidian=true,minecraft:border/adv__story__form_obsidian=false}] run advancement grant @s only minecraft:border/adv__story__form_obsidian
execute as @a[advancements={minecraft:story/iron_tools=true,minecraft:border/adv__story__iron_tools=false}] run advancement grant @s only minecraft:border/adv__story__iron_tools
execute as @a[advancements={minecraft:story/lava_bucket=true,minecraft:border/adv__story__lava_bucket=false}] run advancement grant @s only minecraft:border/adv__story__lava_bucket
execute as @a[advancements={minecraft:story/mine_diamond=true,minecraft:border/adv__story__mine_diamond=false}] run advancement grant @s only minecraft:border/adv__story__mine_diamond
execute as @a[advancements={minecraft:story/mine_stone=true,minecraft:border/adv__story__mine_stone=false}] run advancement grant @s only minecraft:border/adv__story__mine_stone
execute as @a[advancements={minecraft:story/obtain_armor=true,minecraft:border/adv__story__obtain_armor=false}] run advancement grant @s only minecraft:border/adv__story__obtain_armor
execute as @a[advancements={minecraft:story/root=true,minecraft:border/adv__story__root=false}] run advancement grant @s only minecraft:border/adv__story__root
execute as @a[advancements={minecraft:story/shiny_gear=true,minecraft:border/adv__story__shiny_gear=false}] run advancement grant @s only minecraft:border/adv__story__shiny_gear
execute as @a[advancements={minecraft:story/smelt_iron=true,minecraft:border/adv__story__smelt_iron=false}] run advancement grant @s only minecraft:border/adv__story__smelt_iron
execute as @a[advancements={minecraft:story/upgrade_tools=true,minecraft:border/adv__story__upgrade_tools=false}] run advancement grant @s only minecraft:border/adv__story__upgrade_tools
execute as @a[advancements={minecraft:adventure/revaulting=true,minecraft:border/adv__adventure__revaulting=false}] run advancement grant @s only minecraft:border/adv__adventure__revaulting
execute as @a[advancements={minecraft:adventure/summon_iron_golem=true,minecraft:border/adv__adventure__summon_iron_golem=false}] run advancement grant @s only minecraft:border/adv__adventure__summon_iron_golem
execute as @a[advancements={minecraft:adventure/totem_of_undying=true,minecraft:border/adv__adventure__totem_of_undying=false}] run advancement grant @s only minecraft:border/adv__adventure__totem_of_undying
execute as @a[advancements={minecraft:end/dragon_breath=true,minecraft:border/adv__end__dragon_breath=false}] run advancement grant @s only minecraft:border/adv__end__dragon_breath
execute as @a[advancements={minecraft:end/dragon_egg=true,minecraft:border/adv__end__dragon_egg=false}] run advancement grant @s only minecraft:border/adv__end__dragon_egg
execute as @a[advancements={minecraft:end/elytra=true,minecraft:border/adv__end__elytra=false}] run advancement grant @s only minecraft:border/adv__end__elytra
execute as @a[advancements={minecraft:end/respawn_dragon=true,minecraft:border/adv__end__respawn_dragon=false}] run advancement grant @s only minecraft:border/adv__end__respawn_dragon
execute as @a[advancements={minecraft:nether/create_full_beacon=true,minecraft:border/adv__nether__create_full_beacon=false}] run advancement grant @s only minecraft:border/adv__nether__create_full_beacon
execute as @a[advancements={minecraft:story/cure_zombie_villager=true,minecraft:border/adv__story__cure_zombie_villager=false}] run advancement grant @s only minecraft:border/adv__story__cure_zombie_villager
execute as @a[advancements={minecraft:adventure/adventuring_time=true,minecraft:border/adv__adventure__adventuring_time=false}] run advancement grant @s only minecraft:border/adv__adventure__adventuring_time
execute as @a[advancements={minecraft:adventure/arbalistic=true,minecraft:border/adv__adventure__arbalistic=false}] run advancement grant @s only minecraft:border/adv__adventure__arbalistic
execute as @a[advancements={minecraft:adventure/blowback=true,minecraft:border/adv__adventure__blowback=false}] run advancement grant @s only minecraft:border/adv__adventure__blowback
execute as @a[advancements={minecraft:adventure/bullseye=true,minecraft:border/adv__adventure__bullseye=false}] run advancement grant @s only minecraft:border/adv__adventure__bullseye
execute as @a[advancements={minecraft:adventure/hero_of_the_village=true,minecraft:border/adv__adventure__hero_of_the_village=false}] run advancement grant @s only minecraft:border/adv__adventure__hero_of_the_village
execute as @a[advancements={minecraft:adventure/kill_all_mobs=true,minecraft:border/adv__adventure__kill_all_mobs=false}] run advancement grant @s only minecraft:border/adv__adventure__kill_all_mobs
execute as @a[advancements={minecraft:adventure/kill_mob_near_sculk_catalyst=true,minecraft:border/adv__adventure__kill_mob_near_sculk_catalyst=false}] run advancement grant @s only minecraft:border/adv__adventure__kill_mob_near_sculk_catalyst
execute as @a[advancements={minecraft:adventure/overoverkill=true,minecraft:border/adv__adventure__overoverkill=false}] run advancement grant @s only minecraft:border/adv__adventure__overoverkill
execute as @a[advancements={minecraft:adventure/sniper_duel=true,minecraft:border/adv__adventure__sniper_duel=false}] run advancement grant @s only minecraft:border/adv__adventure__sniper_duel
execute as @a[advancements={minecraft:adventure/trim_with_all_exclusive_armor_patterns=true,minecraft:border/adv__adventure__trim_with_all_exclusive_armor_patterns=false}] run advancement grant @s only minecraft:border/adv__adventure__trim_with_all_exclusive_armor_patterns
execute as @a[advancements={minecraft:adventure/two_birds_one_arrow=true,minecraft:border/adv__adventure__two_birds_one_arrow=false}] run advancement grant @s only minecraft:border/adv__adventure__two_birds_one_arrow
execute as @a[advancements={minecraft:adventure/spear_many_mobs=true,minecraft:border/adv__adventure__spear_many_mobs=false}] run advancement grant @s only minecraft:border/adv__adventure__spear_many_mobs
execute as @a[advancements={minecraft:end/levitate=true,minecraft:border/adv__end__levitate=false}] run advancement grant @s only minecraft:border/adv__end__levitate
execute as @a[advancements={minecraft:husbandry/balanced_diet=true,minecraft:border/adv__husbandry__balanced_diet=false}] run advancement grant @s only minecraft:border/adv__husbandry__balanced_diet
execute as @a[advancements={minecraft:husbandry/bred_all_animals=true,minecraft:border/adv__husbandry__bred_all_animals=false}] run advancement grant @s only minecraft:border/adv__husbandry__bred_all_animals
execute as @a[advancements={minecraft:husbandry/complete_catalogue=true,minecraft:border/adv__husbandry__complete_catalogue=false}] run advancement grant @s only minecraft:border/adv__husbandry__complete_catalogue
execute as @a[advancements={minecraft:husbandry/froglights=true,minecraft:border/adv__husbandry__froglights=false}] run advancement grant @s only minecraft:border/adv__husbandry__froglights
execute as @a[advancements={minecraft:husbandry/obtain_netherite_hoe=true,minecraft:border/adv__husbandry__obtain_netherite_hoe=false}] run advancement grant @s only minecraft:border/adv__husbandry__obtain_netherite_hoe
execute as @a[advancements={minecraft:husbandry/whole_pack=true,minecraft:border/adv__husbandry__whole_pack=false}] run advancement grant @s only minecraft:border/adv__husbandry__whole_pack
execute as @a[advancements={minecraft:nether/all_effects=true,minecraft:border/adv__nether__all_effects=false}] run advancement grant @s only minecraft:border/adv__nether__all_effects
execute as @a[advancements={minecraft:nether/all_potions=true,minecraft:border/adv__nether__all_potions=false}] run advancement grant @s only minecraft:border/adv__nether__all_potions
execute as @a[advancements={minecraft:nether/explore_nether=true,minecraft:border/adv__nether__explore_nether=false}] run advancement grant @s only minecraft:border/adv__nether__explore_nether
execute as @a[advancements={minecraft:nether/fast_travel=true,minecraft:border/adv__nether__fast_travel=false}] run advancement grant @s only minecraft:border/adv__nether__fast_travel
execute as @a[advancements={minecraft:nether/netherite_armor=true,minecraft:border/adv__nether__netherite_armor=false}] run advancement grant @s only minecraft:border/adv__nether__netherite_armor
execute as @a[advancements={minecraft:nether/return_to_sender=true,minecraft:border/adv__nether__return_to_sender=false}] run advancement grant @s only minecraft:border/adv__nether__return_to_sender
execute as @a[advancements={minecraft:nether/uneasy_alliance=true,minecraft:border/adv__nether__uneasy_alliance=false}] run advancement grant @s only minecraft:border/adv__nether__uneasy_alliance
