# Function macro: expects arguments {wb_size:<number>}
execute in minecraft:the_nether run worldborder set $(wb_size)
