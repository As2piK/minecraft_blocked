# One-time migration for existing worlds when Items max changes 1671 -> 1667
# If the old sidebar player exists, copy its score into the new one, then remove the old line.

scoreboard players set Items/1667 bc_side 0
scoreboard players operation Items/1667 bc_side = Items/1674 bc_side
team join bc_items Items/1667
team leave Items/1674
scoreboard players reset Items/1674 bc_side
