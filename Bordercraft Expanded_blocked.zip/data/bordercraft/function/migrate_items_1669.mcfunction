# One-time migration for existing worlds when Items max changes 1667 -> 1669
# due to Oxidized Copper Trapdoor and Cactus Flower being added.

execute if score Items/1667 bc_side matches 0.. run scoreboard players add Max bc_border 2
execute if score Items/1667 bc_side matches 0.. run scoreboard players set Items/1674 bc_side 0
execute if score Items/1667 bc_side matches 0.. run scoreboard players operation Items/1674 bc_side = Items/1667 bc_side
team join bc_items Items/1674
team leave Items/1667
scoreboard players reset Items/1667 bc_side

data modify storage bordercraft:state migrate_items_1669 set value 1b
