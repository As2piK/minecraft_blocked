# One-time migration for existing worlds when Items max changes 1669 -> 1671
# due to Copper Torch and Waxed Lightning Rod being added.

execute if score Items/1669 bc_side matches 0.. run scoreboard players add Max bc_border 2
execute if score Items/1669 bc_side matches 0.. run scoreboard players set Items/1674 bc_side 0
execute if score Items/1669 bc_side matches 0.. run scoreboard players operation Items/1674 bc_side = Items/1669 bc_side
team join bc_items Items/1674
team leave Items/1669
scoreboard players reset Items/1669 bc_side

data modify storage bordercraft:state migrate_items_1671 set value 1b
