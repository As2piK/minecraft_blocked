# One-time migration for existing V4 worlds when Items max changes 1675 -> 1672
# Preserve progress on the sidebar while replacing the old max label.
execute if score Items/1675 bc_side matches 0.. run scoreboard players set Items/1672 bc_side 0
execute if score Items/1675 bc_side matches 0.. run scoreboard players operation Items/1672 bc_side = Items/1675 bc_side
team join bc_items Items/1672
team leave Items/1675
scoreboard players reset Items/1675 bc_side
data modify storage bordercraft:state migrate_items_1672 set value 1b
