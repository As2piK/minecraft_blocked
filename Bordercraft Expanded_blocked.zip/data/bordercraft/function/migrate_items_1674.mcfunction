# One-time migration for existing worlds when Items max changes 1678 -> 1674
# due to unobtainable spawn eggs being removed.

execute if score Items/1678 bc_side matches 0.. run scoreboard players add Max bc_border -4
execute if score Items/1678 bc_side matches 0.. run scoreboard players set Items/1674 bc_side 0
execute if score Items/1678 bc_side matches 0.. run scoreboard players operation Items/1674 bc_side = Items/1678 bc_side
team join bc_items Items/1674
team leave Items/1678
scoreboard players reset Items/1678 bc_side

data modify storage bordercraft:state migrate_items_1674 set value 1b
