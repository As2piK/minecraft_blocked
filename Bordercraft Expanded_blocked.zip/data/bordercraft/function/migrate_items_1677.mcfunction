# One-time migration for existing V2 worlds when Items max changes 1677 -> 1674
# due to unobtainable spawn eggs being removed.

execute if score Items/1677 bc_side matches 0.. run scoreboard players set Items/1674 bc_side 0
execute if score Items/1677 bc_side matches 0.. run scoreboard players operation Items/1674 bc_side = Items/1677 bc_side
execute if score Items/1677 bc_side matches 0.. run team join bc_items Items/1674
execute if score Items/1677 bc_side matches 0.. run team leave Items/1677
execute if score Items/1677 bc_side matches 0.. run scoreboard players reset Items/1677 bc_side

data modify storage bordercraft:state migrate_items_1677 set value 1b
