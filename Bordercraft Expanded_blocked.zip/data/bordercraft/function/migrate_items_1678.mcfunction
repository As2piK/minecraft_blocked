# One-time migration for existing worlds when Items max changes 1671 -> 1678
# due to the 7 additional copper bars variants being added.

execute if score Items/1671 bc_side matches 0.. run scoreboard players add Max bc_border 7
execute if score Items/1671 bc_side matches 0.. run scoreboard players set Items/1674 bc_side 0
execute if score Items/1671 bc_side matches 0.. run scoreboard players operation Items/1674 bc_side = Items/1671 bc_side
team join bc_items Items/1674
team leave Items/1671
scoreboard players reset Items/1671 bc_side

data modify storage bordercraft:state migrate_items_1678 set value 1b
