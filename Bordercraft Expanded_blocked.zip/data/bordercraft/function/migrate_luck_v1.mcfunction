# One-time migration when removing Luck potion/arrow variants (4 uniques).
# - Adjust overall max (bc_border: Max) down by 4, preserving any optional-max add-ons.
# - Migrate Items sidebar score from Items/1674 -> Items/1667 if upgrading an existing world.

execute if score Max bc_border matches 2078.. run scoreboard players remove Max bc_border 4
execute if score Items/1674 bc_side matches 0.. run function bordercraft:migrate_items_1667

data modify storage bordercraft:state migrate_luck_v1 set value 1b
