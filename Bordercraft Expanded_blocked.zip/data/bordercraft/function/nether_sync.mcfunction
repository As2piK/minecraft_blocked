# Apply nether border increases based on the global accumulator.
# While NetherAcc >= 8: nether border +2, NetherAcc -= 8

execute in minecraft:the_nether run worldborder add 2
scoreboard players remove NetherAcc bc_nether_accum 8

# Repeat if enough expansions remain.
execute if score NetherAcc bc_nether_accum matches 8.. run function bordercraft:nether_sync
