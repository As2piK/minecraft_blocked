execute if data storage bordercraft:once {adv:{adv__adventure__sniper_duel:1b}} run return 0
data modify storage bordercraft:once adv.adv__adventure__sniper_duel set value 1b
scoreboard players add @s bc_contrib_adv 1
scoreboard players add @s bc_contrib_total 1
scoreboard players add Adv/125 bc_side 1
data modify storage bordercraft:ctx cause set value {"translate":"advancements.adventure.sniper_duel.title"}
data modify storage bordercraft:ctx cause_set set value 1b
function bordercraft:expand_adv
