execute if data storage bordercraft:once {adv:{adv__adventure__trim_with_any_armor_pattern:1b}} run return 0
data modify storage bordercraft:once adv.adv__adventure__trim_with_any_armor_pattern set value 1b
scoreboard players add @s bc_contrib_adv 1
scoreboard players add @s bc_contrib_total 1
scoreboard players add Adv/125 bc_side 1
data modify storage bordercraft:ctx cause set value {"translate":"advancements.adventure.trim_with_any_armor_pattern.title"}
data modify storage bordercraft:ctx cause_set set value 1b
function bordercraft:expand_adv
