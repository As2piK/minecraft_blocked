execute if data storage bordercraft:once {adv:{adv__husbandry__leash_all_frog_variants:1b}} run return 0
data modify storage bordercraft:once adv.adv__husbandry__leash_all_frog_variants set value 1b
scoreboard players add @s bc_contrib_adv 1
scoreboard players add @s bc_contrib_total 1
scoreboard players add Adv/125 bc_side 1
data modify storage bordercraft:ctx cause set value {"translate":"advancements.husbandry.leash_all_frog_variants.title"}
data modify storage bordercraft:ctx cause_set set value 1b
function bordercraft:expand_adv
