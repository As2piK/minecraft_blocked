execute if data storage bordercraft:once {adv:{adv__husbandry__make_a_sign_glow:1b}} run return 0
data modify storage bordercraft:once adv.adv__husbandry__make_a_sign_glow set value 1b
scoreboard players add @s bc_contrib_adv 1
scoreboard players add @s bc_contrib_total 1
scoreboard players add Adv/125 bc_side 1
data modify storage bordercraft:ctx cause set value {"translate":"advancements.husbandry.make_a_sign_glow.title"}
data modify storage bordercraft:ctx cause_set set value 1b
function bordercraft:expand_adv
