execute if data storage bordercraft:once {adv:{adv__husbandry__ride_a_boat_with_a_goat:1b}} run return 0
data modify storage bordercraft:once adv.adv__husbandry__ride_a_boat_with_a_goat set value 1b
scoreboard players add @s bc_contrib_adv 1
scoreboard players add @s bc_contrib_total 1
scoreboard players add Adv/125 bc_side 1
data modify storage bordercraft:ctx cause set value {"translate":"advancements.husbandry.ride_a_boat_with_a_goat.title"}
data modify storage bordercraft:ctx cause_set set value 1b
function bordercraft:expand_adv
