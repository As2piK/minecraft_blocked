execute if data storage bordercraft:once {item:{andesite_slab:1b}} run return 0
data modify storage bordercraft:once item.andesite_slab set value 1b
scoreboard players add @s bc_contrib_items 1
scoreboard players add @s bc_contrib_total 1
scoreboard players add Items/1672 bc_side 1
data modify storage bordercraft:ctx cause set value {"translate":"block.minecraft.andesite_slab"}
data modify storage bordercraft:ctx cause_set set value 1b
function bordercraft:expand
