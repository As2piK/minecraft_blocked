execute if data storage bordercraft:once {item:{chorus_flower:1b}} run return 0
data modify storage bordercraft:once item.chorus_flower set value 1b
scoreboard players add @s bc_contrib_items 1
scoreboard players add @s bc_contrib_total 1
scoreboard players add Items/1672 bc_side 1
data modify storage bordercraft:ctx cause set value {"translate":"block.minecraft.chorus_flower"}
data modify storage bordercraft:ctx cause_set set value 1b
function bordercraft:expand
